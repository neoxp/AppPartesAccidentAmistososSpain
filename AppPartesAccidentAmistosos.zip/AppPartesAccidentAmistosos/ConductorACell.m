//
//  ConductorACell.m
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 4/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import "ConductorACell.h"
#import "TablaPartesTableViewController.h"

@interface ConductorACell ()
-(void) VerificarDatosFormulariPartesAccicentAmistosos;
- (void)changrGreeting;
@end

@implementation ConductorACell
@synthesize imagenView,imagenView2, tomarFoto;
@synthesize textFieldCompanyia, textFieldMatricula, textFieldDNI,textFieldNpoliza,textFieldConductor,textFieldDNIConductor;

@synthesize textFieldFirmaDigital,textFieldFirmaDigitalSegonaPersona;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)viewDidUnload
{
    [self setTextFieldCompanyia:nil];
    [self setTextFieldMatricula:nil];
    [self setTextFieldDNI:nil];
    [self setTextFieldNpoliza:nil];
    [self setTextFieldConductor:nil];
    [self setTextFieldDNIConductor:nil];
    [self setTextFieldFirmaDigital:nil];
    [self setTextFieldFirmaDigitalSegonaPersona:nil];
    
    
    
}


- (void)viewDidLoad
{
    [self VerificarDatosFormulariPartesAccicentAmistosos];
    [self changrGreeting];
    [self enviarDatos];
    [textFieldCompanyia becomeFirstResponder];
    [textFieldMatricula becomeFirstResponder];
    [textFieldDNI becomeFirstResponder];
    [textFieldNpoliza becomeFirstResponder];
    [textFieldConductor becomeFirstResponder];
    [textFieldDNIConductor becomeFirstResponder];
    [textFieldFirmaDigital becomeFirstResponder];
    [textFieldFirmaDigitalSegonaPersona becomeFirstResponder];
    
    
}



- (BOOL)textFieldShouldReturn:(UITextField *)campo {
    if (campo.tag==1) {
        [textFieldCompanyia becomeFirstResponder];
        NSLog(_StringCompanyia ,@"Insertar datos companyia");
    }
    if (campo.tag==2) {
        [textFieldMatricula becomeFirstResponder];
        NSLog(StringMatricula ,@"Insertar Numero Matricula");
    }
    if (campo.tag==3) {
        [textFieldDNI becomeFirstResponder];
        NSLog(_StringDNI ,@"Insertar DNI TITULAR");
    }
    if (campo.tag==4) {
        [textFieldNpoliza becomeFirstResponder];
        NSLog(_StringNPoliza ,@"Insertar Nª Poliza");
        
    }
    if (campo.tag==5) {
        [textFieldConductor becomeFirstResponder];
        NSLog(_StringNPoliza ,@"Insertar Nª Poliza");
    }
    
    if (campo.tag==6) {
        [textFieldDNIConductor becomeFirstResponder];
        
        NSLog(_StringDNI ,@"Insertar DNI conductor");
    }
    
    if (campo.tag==7) {
        [textFieldFirmaDigital becomeFirstResponder];
        NSLog(_StringFirmaDigital ,@"Insertar Firma Digital 1º Conductor ");
    }
    
    if (campo.tag==8) {
        [textFieldFirmaDigitalSegonaPersona becomeFirstResponder];
        NSLog(_StringFirmaDigitalSegonaPersona ,@"Insertar Firma Digital 2º Conductor ");
    }
    
    
    else {
        [textFieldCompanyia resignFirstResponder];
        [textFieldMatricula resignFirstResponder];
        [textFieldDNI resignFirstResponder];
        [textFieldNpoliza resignFirstResponder];
        [textFieldConductor resignFirstResponder];
        [textFieldDNIConductor resignFirstResponder];
        [textFieldFirmaDigital resignFirstResponder];
        [textFieldFirmaDigitalSegonaPersona resignFirstResponder];
        
        [self EnviarFormulario:[self BtnEnviar]];
    }
    return YES;
    
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self animateTextField:textFieldCompanyia up:YES];
    [self animateTextField:textFieldMatricula up:YES];
    [self animateTextField:textFieldDNI up:YES];
    [self animateTextField:textFieldNpoliza up:YES];
    [self animateTextField:textFieldConductor up:YES];
    [self animateTextField:textFieldDNIConductor up:YES];
    [self animateTextField:textFieldFirmaDigital up:YES];
    [self animateTextField:textFieldFirmaDigitalSegonaPersona up:YES];
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    [self animateTextField:textFieldCompanyia up:NO];
    [self animateTextField:textFieldMatricula up:NO];
    [self animateTextField:textFieldDNI up:NO];
    [self animateTextField:textFieldNpoliza up:NO];
    [self animateTextField:textFieldConductor up:NO];
    [self animateTextField:textFieldDNIConductor up:NO];
    [self animateTextField:textFieldFirmaDigital up:NO];
    [self animateTextField:textFieldFirmaDigitalSegonaPersona up:NO];
    
}

-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    int movementDistance = -100;
    float movementDuration = 0.3f;
    int movement = (up ? movementDistance : -movementDistance);
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    [UIView commitAnimations];
    
}

- (void)enviarDatos{
    [textFieldCompanyia becomeFirstResponder];
    [textFieldMatricula becomeFirstResponder];
    [textFieldDNI becomeFirstResponder];
    [textFieldNpoliza becomeFirstResponder];
    [textFieldConductor becomeFirstResponder];
    [textFieldDNIConductor becomeFirstResponder];
    [textFieldFirmaDigital becomeFirstResponder];
    [textFieldFirmaDigitalSegonaPersona becomeFirstResponder];
    NSLog(textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text, textFieldNpoliza.text ,textFieldConductor.text, textFieldDNIConductor.text , textFieldFirmaDigital.text , textFieldFirmaDigitalSegonaPersona.text);
    if ([textFieldCompanyia.text isEqualToString:StringCompanyia] &&
        [textFieldMatricula.text isEqualToString:StringMatricula] &&
        [textFieldDNI.text isEqualToString:StringDNI] &&
        [textFieldNpoliza.text isEqualToString:StringNPoliza] &&
        [textFieldConductor.text isEqualToString:StringConductor] &&
        [textFieldDNIConductor.text isEqualToString:StringDNIConductor] &&
        [textFieldFirmaDigital.text isEqualToString:StringFirmaDigital]&&
        [textFieldFirmaDigitalSegonaPersona.text isEqualToString:StringFirmaDigitalSegonaPersona]) {
        NSLog(textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text, textFieldNpoliza.text ,textFieldConductor.text, textFieldDNIConductor.text , textFieldFirmaDigital.text , textFieldFirmaDigitalSegonaPersona.text ,@"Datos Introducidos correctamente");
    }else{
        NSLog(textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text, textFieldNpoliza.text ,textFieldConductor.text, textFieldDNIConductor.text , textFieldFirmaDigital.text , textFieldFirmaDigitalSegonaPersona.text,@"Datos no Introducidos correctamente");
    }
}




-(void)changrGreeting{
    
    self.StringCompanyia = textFieldCompanyia.text;
    
    NSString *nameStringCompanyia = StringCompanyia;
    
    self.StringMatricula = textFieldMatricula.text;
    
    NSString *nameStringMatricula = StringMatricula;
    
    
    
    if ([StringCompanyia length] == 0)
        
    {
        
        nameStringCompanyia =@"   ";
        
    }
    
    if ([nameStringMatricula length] == 0)
        
    {
        
        nameStringMatricula = @"    ";
        
    }
    
    
    ///////////////////////////////////////////////////
    
    self.StringDNI = textFieldDNI.text;
    
    NSString *nameStringDNI = StringDNI;
    
    self.StringNPoliza = textFieldNpoliza.text;
    
    NSString *nameStringNPoliza = StringNPoliza;
    
    if ([StringDNI length] == 0)
        
    {
        
        nameStringDNI =@"   ";
        
    }
    
    if ([StringNPoliza length] == 0)
        
    {
        
        nameStringNPoliza =@"    ";
        
    }
    
    
    ///////////////////////////////////////////////////
    
    self.StringConductor = textFieldConductor.text;
    
    NSString *nameStringConductor = StringConductor;
    
    self.StringDNIConductor = textFieldDNIConductor.text;
    
    NSString *nameStringDNIConductor = _StringDNIConductor;
    
    if ([StringConductor length] == 0)
        
    {
        
        nameStringConductor =@"   ";
        
    }
    
    if ([_StringDNIConductor length] == 0)
        
    {
        
        nameStringDNIConductor =@"    ";
        
    }
    
    ///////////////////////////////////////////////////
    
    self.StringFirmaDigital = textFieldFirmaDigital.text;
    
    NSString *nameStringFirmaDigital = _StringFirmaDigital;
    
    if ([_StringFirmaDigital length] == 0)
        
    {
        
        nameStringFirmaDigital =@"   ";
        
    }
    else if (nameStringFirmaDigital == _StringFirmaDigitalSegonaPersona == YES)
        
    {
        
        nameStringFirmaDigital =@"   ";
        
        
    }
    
    if (textFieldFirmaDigitalSegonaPersona) {
        
        self.textFieldFirmaDigitalSegonaPersona.text = @" ";
        
        
    }
    
    
    
}



-(void) VerificarDatosFormulariPartesAccicentAmistosos{
    
    self.StringCompanyia = textFieldCompanyia.text;
    
    NSString *nameStringCompanyia = StringCompanyia;
    
    self.StringMatricula = textFieldMatricula.text;
    
    NSString *nameStringMatricula = StringMatricula;
    
    
    
    if ([StringCompanyia length] == 0)
        
    {
        
        nameStringCompanyia =@"   ";
        
    }
    
    if ([nameStringMatricula length] == 0)
        
    {
        
        nameStringMatricula =@"    ";
        
    }
    
    
    ///////////////////////////////////////////////////
    
    self.StringDNI = textFieldDNI.text;
    
    NSString *nameStringDNI = StringDNI;
    
    self.StringNPoliza = textFieldNpoliza.text;
    
    NSString *nameStringNPoliza = StringNPoliza;
    
    if ([StringDNI length] == 0)
        
    {
        
        nameStringDNI =@"   ";
        
    }
    
    if ([StringNPoliza length] == 0)
        
    {
        
        nameStringNPoliza =@"    ";
        
    }
    
    
    ///////////////////////////////////////////////////
    
    self.StringConductor = textFieldConductor.text;
    
    NSString *nameStringConductor = StringConductor;
    
    self.StringDNIConductor = textFieldDNIConductor.text;
    
    NSString *nameStringDNIConductor = _StringDNIConductor;
    
    if ([StringConductor length] == 0)
        
    {
        
        nameStringConductor =@"   ";
        
    }
    
    if ([_StringDNIConductor length] == 0)
        
    {
        
        nameStringDNIConductor =@"    ";
        
    }
    
    ///////////////////////////////////////////////////
    
    self.StringFirmaDigital = textFieldFirmaDigital.text;
    
    NSString *nameStringFirmaDigital = _StringFirmaDigital;
    
    if ([_StringFirmaDigital length] == 0)
        
    {
        
        nameStringFirmaDigital =@"   ";
        
    }
    else if (nameStringFirmaDigital == _StringFirmaDigital == YES)
        
    {
        
        nameStringFirmaDigital =@"   ";
        
    }
    
    NSString *queryURL = [NSString localizedStringWithFormat:textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text, textFieldNpoliza.text ,textFieldConductor.text, textFieldDNIConductor.text , textFieldFirmaDigital.text , textFieldFirmaDigitalSegonaPersona.text];
    
    
    NSURL *url = [NSURL URLWithString:queryURL];
    
    NSString *jsonString = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
    
    NSLog(@"el id de l Object cargara los datos de la lista y los mostrara");
    
    id object = [ ArrayDatosLista initWithObjects:textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text, textFieldNpoliza.text ,textFieldConductor.text, textFieldDNIConductor.text , textFieldFirmaDigital.text , textFieldFirmaDigitalSegonaPersona.text,
                 nil];
    
    NSLog(@"el id de l Object cargara los datos de la lista y los mostrara");
    
    
    if ([object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *objectAsDictionary = (NSDictionary *) object;
        id results = [objectAsDictionary valueForUndefinedKey:@"A"];
        if ([results isKindOfClass:[NSArray class]]) {
            
            
            
            NSArray *arr = [NSArray arrayWithObjects: @"textFieldCompanyia",
                            @"textFieldMatricula",
                            @"textFieldDNI",
                            @"textFieldNpoliza",
                            @"textFieldConductor",
                            @"textFieldDNIConductor",
                            @"textFieldFirmaDigital",
                            @"textFieldFirmaDigitalSegonaPersona", nil];
            [arr componentsJoinedByString: @","];
            
            
            NSError *error = nil;
            
            NSData *data = [NSJSONSerialization dataWithJSONObject:arr=ArrayDatosLista options:kNilOptions error:&error];
            
            NSString *str = [[NSString alloc] initWithData:data encoding:NSTextCheckingTypeTransitInformation];
            
            ArrayDatosLista = results;
            
            ArrayDatosLista = [ArrayDatosLista initWithObjects:textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text, textFieldNpoliza.text ,textFieldConductor.text, textFieldDNIConductor.text , textFieldFirmaDigital.text , textFieldFirmaDigitalSegonaPersona.text,
                               nil];
            
            for (object in arr=ArrayDatosLista=results)
                if ([textFieldCompanyia.text isEqualToString:StringCompanyia] &&
                    [textFieldMatricula.text isEqualToString:StringMatricula] &&
                    [textFieldDNI.text isEqualToString:StringDNI] &&
                    [textFieldNpoliza.text isEqualToString:StringNPoliza] &&
                    [textFieldConductor.text isEqualToString:StringConductor] &&
                    [textFieldDNIConductor.text isEqualToString:StringDNIConductor] &&
                    [textFieldFirmaDigital.text isEqualToString:StringFirmaDigital]&&
                    [textFieldFirmaDigitalSegonaPersona.text isEqualToString:StringFirmaDigitalSegonaPersona],INFINITY==true) {
                    
                    
                    
                    self.StringCompanyia = textFieldCompanyia.text;
                    
                    NSString *nameStringCompanyia = StringCompanyia;
                    
                    self.StringMatricula = textFieldMatricula.text;
                    
                    NSString *nameStringMatricula = StringMatricula;
                    
                    
                    
                    if ([StringCompanyia length] == 0)
                        
                    {
                        
                        nameStringCompanyia =@"   ";
                        ArrayDatosLista = results;
                        
                    }
                    
                    if ([nameStringMatricula length] == 0)
                        
                    {
                        
                        nameStringMatricula =@"    ";
                        ArrayDatosLista = results;
                        
                    }
                    
                    ///////////////////////////////////////////////////
                    
                    self.StringDNI = textFieldDNI.text;
                    
                    NSString *nameStringDNI = StringDNI;
                    
                    self.StringNPoliza = textFieldNpoliza.text;
                    
                    NSString *nameStringNPoliza = StringNPoliza;
                    
                    if ([StringDNI length] == 0)
                        
                    {
                        
                        nameStringDNI =@"   ";
                        ArrayDatosLista = results;
                    }
                    
                    if ([StringNPoliza length] == 0)
                        
                    {
                        
                        nameStringNPoliza =@"    ";
                        ArrayDatosLista = results;
                        
                    }
                    
                    
                    ///////////////////////////////////////////////////
                    
                    self.StringConductor = textFieldConductor.text;
                    
                    NSString *nameStringConductor = StringConductor;
                    
                    self.StringDNIConductor = textFieldDNIConductor.text;
                    
                    NSString *nameStringDNIConductor = _StringDNIConductor;
                    
                    if ([StringConductor length] == 0)
                        
                    {
                        
                        nameStringConductor =@"   ";
                        ArrayDatosLista = results;
                        
                    }
                    
                    if ([_StringDNIConductor length] == 0)
                        
                    {
                        
                        nameStringDNIConductor =@"    ";
                        ArrayDatosLista = results;
                        
                    }
                    
                    ///////////////////////////////////////////////////
                    
                    self.StringFirmaDigital = textFieldFirmaDigital.text;
                    
                    NSString *nameStringFirmaDigital = _StringFirmaDigital;
                    
                    if ([_StringFirmaDigital length] == 0)
                        
                    {
                        
                        nameStringFirmaDigital =@"   ";
                        ArrayDatosLista = results;
                        
                    }
                    else if (nameStringFirmaDigital == _StringFirmaDigital == YES)
                        
                    {
                        
                        nameStringFirmaDigital =@"   ";
                        ArrayDatosLista = results;
                        
                    }
                    
                    
                    NSLog(@"Sigue buscado los datos que esten todos comprobados y todos ya completos");
                    
                    NSLog(@"Si no estan completos seguira buscando en la lista los datos que hacen falta rellenar");
                    
                    
                    [textFieldCompanyia becomeFirstResponder];
                    [textFieldMatricula becomeFirstResponder];
                    [textFieldDNI becomeFirstResponder];
                    [textFieldNpoliza becomeFirstResponder];
                    [textFieldConductor becomeFirstResponder];
                    [textFieldDNIConductor becomeFirstResponder];
                    [textFieldFirmaDigital becomeFirstResponder];
                    [textFieldFirmaDigitalSegonaPersona becomeFirstResponder];
                    NSLog(textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text,
                          textFieldNpoliza.text ,textFieldConductor.text,
                          textFieldDNIConductor.text , textFieldFirmaDigital.text ,
                          textFieldFirmaDigitalSegonaPersona.text,@"%@, ,"
                          ,@"%@, ,"
                          ,@"%@, ,",@"%@, ,",@"%@, ,",@"%@, ,",@"%@, ,"
                          ,@"%@, ," ,@"%@, ,"
                          ,@"Comprovando los datos", TIME_RELATIVE
                          
                          );
                    if ([textFieldCompanyia.text isEqualToString:@"Companyia"] &&
                        [textFieldMatricula.text isEqualToString:@"Matricula"] &&
                        [textFieldDNI.text isEqualToString:@"DNI"] &&
                        [textFieldNpoliza.text isEqualToString:@"Npoliza"] &&
                        [textFieldConductor.text isEqualToString:@"Conductor"] &&
                        [textFieldDNIConductor.text isEqualToString:@"DNIConductor"] &&
                        [textFieldFirmaDigital.text isEqualToString:@"FirmaDigital"]&&
                        [textFieldFirmaDigitalSegonaPersona.text isEqualToString:@"FirmaDigital"]) {
                        NSLog(@"Datos Introducidos correctamente");
                        
                        ([textFieldCompanyia.text isEqualToString:StringCompanyia] &&
                         [textFieldMatricula.text isEqualToString:StringMatricula] &&
                         [textFieldDNI.text isEqualToString:StringDNI] &&
                         [textFieldNpoliza.text isEqualToString:StringNPoliza] &&
                         [textFieldConductor.text isEqualToString:StringConductor] &&
                         [textFieldDNIConductor.text isEqualToString:StringDNIConductor] &&
                         [textFieldFirmaDigital.text isEqualToString:StringFirmaDigital]&&
                         [textFieldFirmaDigitalSegonaPersona.text isEqualToString:StringFirmaDigitalSegonaPersona]);
                        
                    }else{
                        NSLog(textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text, textFieldNpoliza.text ,textFieldConductor.text, textFieldDNIConductor.text , textFieldFirmaDigital.text , textFieldFirmaDigitalSegonaPersona.text, [textFieldCompanyia.text isEqualToString:@"Companyia"] &&
                              [textFieldMatricula.text isEqualToString:@"Matricula"] &&
                              [textFieldDNI.text isEqualToString:@"DNI"] &&
                              [textFieldNpoliza.text isEqualToString:@"Npoliza"] &&
                              [textFieldConductor.text isEqualToString:@"Conductor"] &&
                              [textFieldDNIConductor.text isEqualToString:@"DNIConductor"] &&
                              [textFieldFirmaDigital.text isEqualToString:@"FirmaDigital"]&&
                              [textFieldFirmaDigitalSegonaPersona.text isEqualToString:@"FirmaDigital"], @"Datos no Introducidos correctamente");
                        
                    }
                    ArrayDatosLista = results;
                    NSLog(textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text, textFieldNpoliza.text ,textFieldConductor.text, textFieldDNIConductor.text , textFieldFirmaDigital.text , textFieldFirmaDigitalSegonaPersona.text,@"Mostrando Resultado de los datos",[textFieldCompanyia.text isEqualToString:StringCompanyia] &&
                          [textFieldMatricula.text isEqualToString:StringMatricula] &&
                          [textFieldDNI.text isEqualToString:StringDNI] &&
                          [textFieldNpoliza.text isEqualToString:StringNPoliza] &&
                          [textFieldConductor.text isEqualToString:StringConductor] &&
                          [textFieldDNIConductor.text isEqualToString:StringDNIConductor] &&
                          [textFieldFirmaDigital.text isEqualToString:StringFirmaDigital]&&
                          [textFieldFirmaDigitalSegonaPersona.text isEqualToString:StringFirmaDigitalSegonaPersona]
                          );
                }
            
        }
    }
    if ([object isKindOfClass:[NSArray class]]) {
        ArrayDatosLista = object;
        
    }
    
    
}

-(void) touchesBegan :(NSSet *) touches withEvent:(UIEvent *)event

{
    
    [textFieldCompanyia resignFirstResponder];
    
    [textFieldMatricula resignFirstResponder];
    
    [textFieldDNI resignFirstResponder];
    
    [textFieldNpoliza resignFirstResponder];
    
    [textFieldConductor resignFirstResponder];
    
    [textFieldDNIConductor resignFirstResponder];
    
    [textFieldFirmaDigital resignFirstResponder];
    
    [super touchesBegan:touches withEvent:event];
    
}


- (void)dealloc {
    
    [textFieldCompanyia autoContentAccessingProxy];
    
    [textFieldMatricula autoContentAccessingProxy];
    
    [textFieldDNI autoContentAccessingProxy];
    
    [textFieldNpoliza autoContentAccessingProxy];
    
    [textFieldConductor autoContentAccessingProxy];
    
    [textFieldDNI autoContentAccessingProxy];
    
    [textFieldDNIConductor autoContentAccessingProxy];
    
    [textFieldFirmaDigital autoContentAccessingProxy];
    
    [StringCompanyia autoContentAccessingProxy];
    [StringMatricula autoContentAccessingProxy];
    [StringDNI autoContentAccessingProxy];
    [StringNPoliza autoContentAccessingProxy];
    [StringConductor autoContentAccessingProxy];
    [_StringDNIConductor autoContentAccessingProxy];
    [_StringFirmaDigital autoContentAccessingProxy];
    
    [imagenView autoContentAccessingProxy];
    [tomarFoto autoContentAccessingProxy];
    [super autoContentAccessingProxy];
    
}

-(IBAction)EnviarFormulario:(id)sender {
    NSArray *toRecipents = [NSArray arrayWithObject:@"ejemplo@lacaixa.es"];
    
    MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
    mc.mailComposeDelegate = self;
    
    [mc setMessageBody:StringCompanyia isHTML:NO];
    
    [mc setMessageBody:StringMatricula isHTML:NO];
    
    [mc setMessageBody:StringDNI isHTML:NO];
    
    [mc setMessageBody:StringNPoliza isHTML:NO];
    
    [mc setMessageBody:StringConductor isHTML:NO];
    
    [mc setMessageBody:StringDNIConductor isHTML:NO];
    
    [mc setMessageBody:StringFirmaDigital isHTML:NO];
    
    [mc setMessageBody:StringFirmaDigitalSegonaPersona isHTML:NO];
    
    
    
    [mc setToRecipients:toRecipents];
    
    [textFieldCompanyia becomeFirstResponder];
    [textFieldMatricula becomeFirstResponder];
    [textFieldDNI becomeFirstResponder];
    [textFieldNpoliza becomeFirstResponder];
    [textFieldConductor becomeFirstResponder];
    [textFieldDNIConductor becomeFirstResponder];
    [textFieldFirmaDigital becomeFirstResponder];
    [textFieldFirmaDigitalSegonaPersona becomeFirstResponder];
    NSLog(textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text,
          textFieldNpoliza.text ,textFieldConductor.text,
          textFieldDNIConductor.text , textFieldFirmaDigital.text ,
          textFieldFirmaDigitalSegonaPersona.text,@"%@, ,"
          ,@"%@, ,",@"%@, ,",@"%@, ,",@"%@, ,",@"%@, ,",@"%@, ,"
          ,@"%@, ," ,@"%@, ," ,@"Comprobando los datos"
          , TIME_RELATIVE
          );
    
    if  ([textFieldCompanyia.text isEqualToString:StringCompanyia] &&
         [textFieldMatricula.text isEqualToString:StringMatricula] &&
         [textFieldDNI.text isEqualToString:StringDNI] &&
         [textFieldNpoliza.text isEqualToString:StringNPoliza] &&
         [textFieldConductor.text isEqualToString:StringConductor] &&
         [textFieldDNIConductor.text isEqualToString:StringDNIConductor] &&
         [textFieldFirmaDigital.text isEqualToString:StringFirmaDigital]&&
         [textFieldFirmaDigitalSegonaPersona.text isEqualToString:StringFirmaDigitalSegonaPersona]){
        NSLog(@"Datos Introducidos correctamente");
        ([textFieldCompanyia.text isEqualToString:StringCompanyia] &&
         [textFieldMatricula.text isEqualToString:StringMatricula] &&
         [textFieldDNI.text isEqualToString:StringDNI] &&
         [textFieldNpoliza.text isEqualToString:StringNPoliza] &&
         [textFieldConductor.text isEqualToString:StringConductor] &&
         [textFieldDNIConductor.text isEqualToString:StringDNIConductor] &&
         [textFieldFirmaDigital.text isEqualToString:StringFirmaDigital]&&
         [textFieldFirmaDigitalSegonaPersona.text isEqualToString:StringFirmaDigitalSegonaPersona]);
        
    }else{
        NSLog(@"Datos no Introducidos correctamente");
        ([textFieldCompanyia.text isEqualToString:StringCompanyia] &&
         [textFieldMatricula.text isEqualToString:StringMatricula] &&
         [textFieldDNI.text isEqualToString:StringDNI] &&
         [textFieldNpoliza.text isEqualToString:StringNPoliza] &&
         [textFieldConductor.text isEqualToString:StringConductor] &&
         [textFieldDNIConductor.text isEqualToString:StringDNIConductor] &&
         [textFieldFirmaDigital.text isEqualToString:StringFirmaDigital]&&
         [textFieldFirmaDigitalSegonaPersona.text isEqualToString:StringFirmaDigitalSegonaPersona]);
        
        NSLog(textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text, textFieldNpoliza.text ,textFieldConductor.text, textFieldDNIConductor.text , textFieldFirmaDigital.text , textFieldFirmaDigitalSegonaPersona.text,@"Mostrando Resultado de los datos",[textFieldCompanyia.text isEqualToString:StringCompanyia] &&
              [textFieldMatricula.text isEqualToString:StringMatricula] &&
              [textFieldDNI.text isEqualToString:StringDNI] &&
              [textFieldNpoliza.text isEqualToString:StringNPoliza] &&
              [textFieldConductor.text isEqualToString:StringConductor] &&
              [textFieldDNIConductor.text isEqualToString:StringDNIConductor] &&
              [textFieldFirmaDigital.text isEqualToString:StringFirmaDigital]&&
              [textFieldFirmaDigitalSegonaPersona.text isEqualToString:StringFirmaDigitalSegonaPersona]
              );
        
        NSLog(textFieldCompanyia.text, textFieldMatricula.text ,textFieldDNI.text, textFieldNpoliza.text ,textFieldConductor.text, textFieldDNIConductor.text , textFieldFirmaDigital.text , textFieldFirmaDigitalSegonaPersona.text,@"Mostrando Resultado de los datos",[textFieldCompanyia.text isEqualToString:StringCompanyia] &&
              [textFieldMatricula.text isEqualToString:StringMatricula] &&
              [textFieldDNI.text isEqualToString:StringDNI] &&
              [textFieldNpoliza.text isEqualToString:StringNPoliza] &&
              [textFieldConductor.text isEqualToString:StringConductor] &&
              [textFieldDNIConductor.text isEqualToString:StringDNIConductor] &&
              [textFieldFirmaDigital.text isEqualToString:StringFirmaDigital]&&
              [textFieldFirmaDigitalSegonaPersona.text isEqualToString:StringFirmaDigitalSegonaPersona]
              );
        
    }
    
}


- (IBAction)tomarFoto:(id)sender
{
    UIImagePickerController * picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;

   
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    [picker dismissModalViewControllerAnimated:YES];
    imagenView.image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    imagenView2.image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
}


- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            cargado.text = @"Cancelado";
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            cargado.text = @"Guardado";
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            cargado.text = @"Enviado";
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    
}



@end
