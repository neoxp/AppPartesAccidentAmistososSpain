//
//  ParteA+CoreDataProperties.m
//  AppPartesAccidentAmistosos
//
//  Created by HackerMaster   on 16/11/16.
//  Copyright © 2016 Emili Marqués Forés. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "ParteA+CoreDataProperties.h"

@implementation ParteA (CoreDataProperties)

@dynamic novaMatricula;
@dynamic matricula;
@dynamic numeroPoliza;
@dynamic companyia;
@dynamic dni;
@dynamic conductor;
@dynamic firmaconductorA;
@dynamic fotosaccident;
@dynamic id;
@dynamic relationship;

@end
