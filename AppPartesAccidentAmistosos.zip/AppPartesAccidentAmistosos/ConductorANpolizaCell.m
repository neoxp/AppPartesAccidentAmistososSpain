//
//  ConductorANpolizaCell.m
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 4/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import "ConductorANpolizaCell.h"

@interface ConductorANpolizaCell ()
-(void) VerificarDatosFormulariPartesAccicentAmistosos;
- (void)changrGreeting;
@end

@implementation ConductorANpolizaCell
@synthesize textFieldNpoliza;



- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
- (void)viewDidUnload
{
    [self setTextFieldNpoliza:nil];
    
}


- (void)viewDidLoad
{
    [self VerificarDatosFormulariPartesAccicentAmistosos];
    [self changrGreeting];
    [self enviarDatos];
    [textFieldNpoliza becomeFirstResponder];
    
    
}



- (BOOL)textFieldShouldReturn:(UITextField *)campo {
    if (campo.tag==1) {
        [textFieldNpoliza becomeFirstResponder];
        NSLog(StringNPoliza ,@"Insertar datos companyia");
    }
    
    
    
    else {
        [textFieldNpoliza resignFirstResponder];
        
    }
    return YES;
    
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self animateTextField:textFieldNpoliza up:YES];
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    [self animateTextField:textFieldNpoliza up:NO];
    
}

-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    int movementDistance = -100;
    float movementDuration = 0.3f;
    int movement = (up ? movementDistance : -movementDistance);
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    [UIView commitAnimations];
    
}

- (void)enviarDatos{
    [textFieldNpoliza becomeFirstResponder];
    NSLog(textFieldNpoliza.text);
    if ([textFieldNpoliza.text isEqualToString:StringNPoliza]) {
        NSLog(textFieldNpoliza.text ,@"Datos Introducidos correctamente");
    }else{
        NSLog(textFieldNpoliza.text,@"Datos no Introducidos correctamente");
    }
}




-(void)changrGreeting{
    
    self->StringNPoliza = textFieldNpoliza.text;
    
    NSString *nameStringNPoliza = StringNPoliza;
    
    
    
    if ([StringNPoliza length] == 0)
        
    {
        
        nameStringNPoliza =@"   ";
        
    }
    
    
}



-(void) VerificarDatosFormulariPartesAccicentAmistosos{
    
    self->StringNPoliza = textFieldNpoliza.text;
    
    NSString *nameStringNPoliza = StringNPoliza;
    
    
    
    NSString *queryURL = [NSString localizedStringWithFormat:textFieldNpoliza.text];
    
    
    NSURL *url = [NSURL URLWithString:queryURL];
    
    NSString *jsonString = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
    
    NSLog(@"el id de l Object cargara los datos de la lista y los mostrara");
    
    id object = [ ArrayDatosLista initWithObjects:textFieldNpoliza.text,nil];
    
    NSLog(@"el id de l Object cargara los datos de la lista y los mostrara");
    
    
    if ([object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *objectAsDictionary = (NSDictionary *) object;
        id results = [objectAsDictionary valueForUndefinedKey:@"A"];
        if ([results isKindOfClass:[NSArray class]]) {
            
            
            
            NSArray *arr = [NSArray arrayWithObjects: @"textFieldNpoliza", nil];
            [arr componentsJoinedByString: @","];
            
            
            NSError *error = nil;
            
            NSData *data = [NSJSONSerialization dataWithJSONObject:arr=ArrayDatosLista options:kNilOptions error:&error];
            
            NSString *str = [[NSString alloc] initWithData:data encoding:NSTextCheckingTypeTransitInformation];
            
            ArrayDatosLista = results;
            
            ArrayDatosLista = [ArrayDatosLista initWithObjects:textFieldNpoliza.text,nil];
            
            for (object in arr=ArrayDatosLista=results)
                if ([textFieldNpoliza.text isEqualToString:StringNPoliza],INFINITY==true) {
                    
                    
                    
                    self->StringNPoliza = textFieldNpoliza.text;
                    
                    NSString *nameStringNPoliza = StringNPoliza;
                    
                    
                    
                    
                    NSLog(@"Sigue buscado los datos que esten todos comprobados y todos ya completos");
                    
                    NSLog(@"Si no estan completos seguira buscando en la lista los datos que hacen falta rellenar");
                    
                    
                    [textFieldNpoliza becomeFirstResponder];
                    NSLog(textFieldNpoliza.text,@"%@, ," ,@"Comprovando los datos", TIME_RELATIVE
                          
                          );
                    if ([textFieldNpoliza.text isEqualToString:@"Companyia"]) {
                        NSLog(@"Datos Introducidos correctamente");
                        
                        ([textFieldNpoliza.text isEqualToString:StringNPoliza]);
                        
                    }else{
                        NSLog(textFieldNpoliza.text ,@"Companyia");
                        
                    }
                    ArrayDatosLista = results;
                    NSLog(textFieldNpoliza.text ,@"Mostrando Resultado de los datos",[textFieldNpoliza.text isEqualToString:StringNPoliza] );
                }
            
        }
    }
    if ([object isKindOfClass:[NSArray class]]) {
        ArrayDatosLista = object;
        
    }
    
    
}

-(void) touchesBegan :(NSSet *) touches withEvent:(UIEvent *)event

{
    
    [textFieldNpoliza resignFirstResponder];
    
    
    [super touchesBegan:touches withEvent:event];
    
}


- (void)dealloc {
    
    [textFieldNpoliza autoContentAccessingProxy];
    
    
    [StringNPoliza autoContentAccessingProxy];
    [super autoContentAccessingProxy];
    
}

-(IBAction)EnviarFormulario:(id)sender {
    NSArray *toRecipents = [NSArray arrayWithObject:@"ejemplo@lacaixa.es"];
    
    MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
    mc.mailComposeDelegate = self;
    
    [mc setMessageBody:StringNPoliza isHTML:NO];
    
    
    
    [mc setToRecipients:toRecipents];
    
    [textFieldNpoliza becomeFirstResponder];
    
    NSLog(textFieldNpoliza.text,@"%@, ,",@"Comprobando los datos"
          , TIME_RELATIVE
          );
    
    if  ([textFieldNpoliza.text isEqualToString:StringNPoliza]){
        NSLog(@"Datos Introducidos correctamente");
        ([textFieldNpoliza.text isEqualToString:StringNPoliza]);
        
    }else{
        NSLog(@"Datos no Introducidos correctamente");
        ([textFieldNpoliza.text isEqualToString:StringNPoliza]);
        
        NSLog(textFieldNpoliza.text,@"Mostrando Resultado de los datos",
              [textFieldNpoliza.text isEqualToString:StringNPoliza]  );
        
        NSLog(textFieldNpoliza.text, @"Mostrando Resultado de los datos",[textFieldNpoliza.text isEqualToString:StringNPoliza]);
        
    }
    
}


- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            cargado.text = @"Cancelado";
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            cargado.text = @"Guardado";
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            cargado.text = @"Enviado";
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    
}



@end
