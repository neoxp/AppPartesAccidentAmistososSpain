//
//  ParteA.m
//  AppPartesAccidentAmistosos
//
//  Created by HackerMaster   on 16/11/16.
//  Copyright © 2016 Emili Marqués Forés. All rights reserved.
//

#import "ParteA.h"
#import "DatosID.h"

@implementation ParteA

// Insert code here to add functionality to your managed object subclass

@end
