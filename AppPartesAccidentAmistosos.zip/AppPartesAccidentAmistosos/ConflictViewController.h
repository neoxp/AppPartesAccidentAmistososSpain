

#import <UIKit/UIKit.h>
#import <iCloud/iCloud.h>

@interface ConflictViewController : UITableViewController

- (IBAction)cancel:(id)sender;

@property (strong) NSString *documentName;
@property (strong) NSArray *documentVersions;

@end
