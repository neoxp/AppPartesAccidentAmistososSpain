

#import <UIKit/UIKit.h>
#import <iCloud/iCloud.h>

@interface WelcomeViewController : UIViewController <iCloudDelegate, UIAlertViewDelegate>

@property (weak, nonatomic) IBOutlet UIButton *startCloudButton;
@property (weak, nonatomic) IBOutlet UIButton *setupCloudButton;

- (IBAction)startCloud:(id)sender;
- (IBAction)setupCloud:(id)sender;

@end
