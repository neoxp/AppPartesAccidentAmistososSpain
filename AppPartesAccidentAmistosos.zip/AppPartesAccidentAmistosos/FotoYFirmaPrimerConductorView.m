//
//  FotoYFirmaPrimerConductorView.m
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 8/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import "FotoYFirmaPrimerConductorView.h"

#import "ViewController.h"
#import "TablaPartesTableViewController.h"
#import "WelcomeViewController.h"
#import "TLTransitionAnimator.h"
#import "MHPrettyDate.h"
#import "ShareViewController.h"
#import "ConflictViewController.h"
#import "DocumentViewController.h"
#import "ListViewController.h"
#import "ConductorACell.h"
#import "FotoYFirmaConductorACell.h"
#import "FotoYFirmaConductorBCell.h"
#import "ConductorBCell.h"
#import "ViewController.h"
#import "TablaPartesTableViewController.h"

@interface FotoYFirmaPrimerConductorView ()
-(void) VerificarDatosFormulariPartesAccicentAmistosos;
- (void)changrGreeting;
@end

@implementation FotoYFirmaPrimerConductorView
@synthesize imagenView1,imagenView2, tomarFoto;

@synthesize textFieldFirmaDigital;



- (void)viewDidUnload
{
    
    
}



- (IBAction)tomarFoto:(id)sender
{
	UIImagePickerController * picker = [[UIImagePickerController alloc] init];
	picker.delegate = self;
	picker.sourceType = UIImagePickerControllerSourceTypeCamera;
 
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
	[picker dismissModalViewControllerAnimated:YES];
	imagenView1.image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    imagenView2.image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
}


- (void)dealloc {
    
   
     [imagenView1 autoContentAccessingProxy];
     [imagenView2 autoContentAccessingProxy];
    [tomarFoto autoContentAccessingProxy];
    [super autoContentAccessingProxy];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


@end
