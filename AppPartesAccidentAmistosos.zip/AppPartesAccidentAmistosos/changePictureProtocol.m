//
//  changePictureProtocol.m
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 8/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import "changePictureProtocol.h"

@implementation changePictureProtocol

@end
