//
//  Bookmark.h
//  bolduoptic
//
//  Created by HackerWebMaster on 2/8/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyTextDocument.h"
#import "ViewController.h"
#import "ViewController2.h"
#import <AudioToolbox/AudioServices.h>


@interface Bookmark : NSObject <NSCoding> {
    NSString *_name;
    NSString *_url;
}

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *url;

- (id)initWithName:(NSString *)name andURL:(NSString *)url;

@end