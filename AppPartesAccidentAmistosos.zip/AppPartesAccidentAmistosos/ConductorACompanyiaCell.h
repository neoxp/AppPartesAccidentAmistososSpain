//
//  ConductorACompanyiaCell.h
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 4/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MessageUI/MessageUI.h>
#import <CFNetwork/CFNetwork.h>
#import <Accelerate/Accelerate.h>
#import <sqlite3.h>
#import <sqlite3ext.h>
#import <CoreData/CoreData.h>


@interface ConductorACompanyiaCell : UITableViewCell<UITextFieldDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,MFMailComposeViewControllerDelegate, UIDataSourceModelAssociation,NSMutableCopying,NSXMLParserDelegate>{
    
    NSString *StringCompanyia;
     NSArray *ArrayDatosLista;

    IBOutlet UILabel *cargado;
}

@property (weak, nonatomic)  IBOutlet UITextField *textFieldCompanyia;


@property (nonatomic, copy)  NSString *StringCompanyia;



@end
