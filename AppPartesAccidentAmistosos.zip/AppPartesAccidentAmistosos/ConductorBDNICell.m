//
//  ConductorBDNICell.m
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 4/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import "ConductorBDNICell.h"

@interface ConductorBDNICell ()
-(void) VerificarDatosFormulariPartesAccicentAmistosos;
- (void)changrGreeting;
@end

@implementation ConductorBDNICell
@synthesize textFieldDNI;



- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
- (void)viewDidUnload
{
    [self setTextFieldDNI:nil];
    
}


- (void)viewDidLoad
{
    [self VerificarDatosFormulariPartesAccicentAmistosos];
    [self changrGreeting];
    [self enviarDatos];
    [textFieldDNI becomeFirstResponder];
    
    
}



- (BOOL)textFieldShouldReturn:(UITextField *)campo {
    if (campo.tag==1) {
        [textFieldDNI becomeFirstResponder];
        NSLog(_StringDNI ,@"Insertar datos companyia");
    }
    
    
    
    else {
        [textFieldDNI resignFirstResponder];
        
    }
    return YES;
    
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self animateTextField:textFieldDNI up:YES];
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    [self animateTextField:textFieldDNI up:NO];
    
}

-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    int movementDistance = -100;
    float movementDuration = 0.3f;
    int movement = (up ? movementDistance : -movementDistance);
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    [UIView commitAnimations];
    
}

- (void)enviarDatos{
    [textFieldDNI becomeFirstResponder];
    NSLog(textFieldDNI.text);
    if ([textFieldDNI.text isEqualToString:StringDNI]) {
        NSLog(textFieldDNI.text ,@"Datos Introducidos correctamente");
    }else{
        NSLog(textFieldDNI.text,@"Datos no Introducidos correctamente");
    }
}




-(void)changrGreeting{
    
    self.StringDNI = textFieldDNI.text;
    
    NSString *nameStringDNI = StringDNI;
    
    
    
    if ([StringDNI length] == 0)
        
    {
        
        nameStringDNI =@"   ";
        
    }
    
    
}



-(void) VerificarDatosFormulariPartesAccicentAmistosos{
    
    self.StringDNI = textFieldDNI.text;
    
    NSString *nameStringDNI = StringDNI;
    
    
    
    NSString *queryURL = [NSString localizedStringWithFormat:textFieldDNI.text];
    
    
    NSURL *url = [NSURL URLWithString:queryURL];
    
    NSString *jsonString = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
    
    NSLog(@"el id de l Object cargara los datos de la lista y los mostrara");
    
    id object = [ ArrayDatosLista initWithObjects:textFieldDNI.text,nil];
    
    NSLog(@"el id de l Object cargara los datos de la lista y los mostrara");
    
    
    if ([object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *objectAsDictionary = (NSDictionary *) object;
        id results = [objectAsDictionary valueForUndefinedKey:@"A"];
        if ([results isKindOfClass:[NSArray class]]) {
            
            
            
            NSArray *arr = [NSArray arrayWithObjects: @"textFieldDNI", nil];
            [arr componentsJoinedByString: @","];
            
            
            NSError *error = nil;
            
            NSData *data = [NSJSONSerialization dataWithJSONObject:arr=ArrayDatosLista options:kNilOptions error:&error];
            
            NSString *str = [[NSString alloc] initWithData:data encoding:NSTextCheckingTypeTransitInformation];
            
            ArrayDatosLista = results;
            
            ArrayDatosLista = [ArrayDatosLista initWithObjects:textFieldDNI.text,nil];
            
            for (object in arr=ArrayDatosLista=results)
                if ([textFieldDNI.text isEqualToString:StringDNI],INFINITY==true) {
                    
                    
                    
                    self.StringDNI = textFieldDNI.text;
                    
                    NSString *nameStringDNI = StringDNI;
                    
                    
                    
                    
                    NSLog(@"Sigue buscado los datos que esten todos comprobados y todos ya completos");
                    
                    NSLog(@"Si no estan completos seguira buscando en la lista los datos que hacen falta rellenar");
                    
                    
                    [textFieldDNI becomeFirstResponder];
                    NSLog(textFieldDNI.text,@"%@, ," ,@"Comprovando los datos", TIME_RELATIVE
                          
                          );
                    if ([textFieldDNI.text isEqualToString:@"Companyia"]) {
                        NSLog(@"Datos Introducidos correctamente");
                        
                        ([textFieldDNI.text isEqualToString:StringDNI]);
                        
                    }else{
                        NSLog(textFieldDNI.text ,@"Companyia");
                        
                    }
                    ArrayDatosLista = results;
                    NSLog(textFieldDNI.text ,@"Mostrando Resultado de los datos",[textFieldDNI.text isEqualToString:StringDNI] );
                }
            
        }
    }
    if ([object isKindOfClass:[NSArray class]]) {
        ArrayDatosLista = object;
        
    }
    
    
}

-(void) touchesBegan :(NSSet *) touches withEvent:(UIEvent *)event

{
    
    [textFieldDNI resignFirstResponder];
    
    
    [super touchesBegan:touches withEvent:event];
    
}


- (void)dealloc {
    
    [textFieldDNI autoContentAccessingProxy];
    
    
    [StringDNI autoContentAccessingProxy];
    [super autoContentAccessingProxy];
    
}

-(IBAction)EnviarFormulario:(id)sender {
    NSArray *toRecipents = [NSArray arrayWithObject:@"ejemplo@lacaixa.es"];
    
    MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
    mc.mailComposeDelegate = self;
    
    [mc setMessageBody:StringDNI isHTML:NO];
    
    
    
    [mc setToRecipients:toRecipents];
    
    [textFieldDNI becomeFirstResponder];
    
    NSLog(textFieldDNI.text,@"%@, ,",@"Comprobando los datos"
          , TIME_RELATIVE
          );
    
    if  ([textFieldDNI.text isEqualToString:StringDNI]){
        NSLog(@"Datos Introducidos correctamente");
        ([textFieldDNI.text isEqualToString:StringDNI]);
        
    }else{
        NSLog(@"Datos no Introducidos correctamente");
        ([textFieldDNI.text isEqualToString:StringDNI]);
        
        NSLog(textFieldDNI.text,@"Mostrando Resultado de los datos",
              [textFieldDNI.text isEqualToString:StringDNI]  );
        
        NSLog(textFieldDNI.text, @"Mostrando Resultado de los datos",[textFieldDNI.text isEqualToString:StringDNI]);
        
    }
    
}


- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            cargado.text = @"Cancelado";
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            cargado.text = @"Guardado";
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            cargado.text = @"Enviado";
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    
}



@end
