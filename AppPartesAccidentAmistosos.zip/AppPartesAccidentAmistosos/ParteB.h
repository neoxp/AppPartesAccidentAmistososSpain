//
//  ParteB.h
//  AppPartesAccidentAmistosos
//
//  Created by HackerMaster   on 16/11/16.
//  Copyright © 2016 Emili Marqués Forés. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface ParteB : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "ParteB+CoreDataProperties.h"
