//
//  FotoYFirmaConductorBCell.h
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 4/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MessageUI/MessageUI.h>
#import <CFNetwork/CFNetwork.h>
#import <Accelerate/Accelerate.h>
#import <sqlite3.h>
#import <sqlite3ext.h>
#import <CoreData/CoreData.h>


@interface FotoYFirmaConductorBCell : UITableViewCell<UITextFieldDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,MFMailComposeViewControllerDelegate, UIDataSourceModelAssociation,NSMutableCopying,NSXMLParserDelegate>{
    
    NSString *StringCompanyia;
    NSString *StringMatricula;
    NSString *StringDNI;
    NSString *StringNPoliza;
    NSString *StringConductor;
    NSString *StringDNIConductor;
    NSString *StringFirmaDigital;
    NSString *StringFirmaDigitalSegonaPersona;
    
    
    NSArray *ArrayDatosLista;
    UIImageView *imagenView;
    UIButton    *tomarFoto;
    IBOutlet UILabel *cargado;
    
}

@property (weak, nonatomic)  IBOutlet UITextField *textFieldCompanyia;

@property (weak, nonatomic)  IBOutlet UITextField *textFieldMatricula;

@property (weak, nonatomic) IBOutlet UITextField *textFieldDNI;

@property (weak, nonatomic)  IBOutlet UITextField *textFieldNpoliza;

@property (weak, nonatomic)  IBOutlet UITextField *textFieldConductor;

@property (weak, nonatomic) IBOutlet UITextField *textFieldDNIConductor;


@property (weak, nonatomic) IBOutlet UITextField *textFieldFirmaDigital;
@property (weak, nonatomic) IBOutlet UITextField *textFieldFirmaDigitalSegonaPersona;

@property (nonatomic, copy)  NSString *StringCompanyia;
@property (nonatomic, copy)  NSString *StringMatricula;
@property (nonatomic, copy)  NSString *StringDNI;
@property (nonatomic, copy)  NSString *StringNPoliza;
@property (nonatomic, copy)  NSString *StringConductor;
@property (nonatomic, copy)  NSString *StringDNIConductor;

@property (nonatomic, copy) NSString *StringFirmaDigital;
@property (nonatomic, copy) NSString *StringFirmaDigitalSegonaPersona;

@property (nonatomic, retain) IBOutlet UIImageView *imagenView;
@property (nonatomic, retain) IBOutlet UIButton *tomarFoto;
@property (weak, nonatomic) IBOutlet UIButton *BtnEnviar;

- (IBAction)tomarFoto:(id)sender;

-(IBAction)EnviarFormulario:(id)sender;

@end
