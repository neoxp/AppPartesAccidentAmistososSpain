//
//  main.m
//  AppPartesAccidentAmistosos
//
//  Created by Hackermaster on 20/04/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
