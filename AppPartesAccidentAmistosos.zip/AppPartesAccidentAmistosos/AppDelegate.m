//
//  AppDelegate.m
//  AppPartesAccidentAmistosos
//
//  Created by Hackermaster on 20/04/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import "AppDelegate.h"

#import "UbiquityStoreManager.h"
#import "ParteB.h"
#import "ParteB+CoreDataProperties.h"
#import "DatosID.h"
#import "DatosID.h"
#import "ParteB.h"
#import "ParteA.h"
#import "ParteA+CoreDataProperties.h"
#import "ParteA.h"
#import "DatosID.h"

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

@implementation AppDelegate{
    UIAlertView *cloudContentCorruptedAlert;
    UIAlertView *cloudContentHealingAlert;
    UIAlertView *handleCloudContentWarningAlert;
    UIAlertView *handleLocalStoreAlert;
    ViewController *ViewController;
    ViewController2 *ViewController2;
}


@synthesize pickerCaducidad, txtNotificacion, textoNotificacion,ubiquityStoreManager;

NSString *kNotificationTextKey = @"kNotificationTextKey";



#pragma mark -
#pragma mark === Text Field Delegate ===
#pragma mark -

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [textField resignFirstResponder];
    return YES;
}

#pragma mark -
#pragma mark === Métodos públicos ===
#pragma mark -

-(void)despliegaNotificacion:(NSString *)mensaje
{
    [txtNotificacion setText:mensaje];
}

- (void)programarNotificacion
{
    UILocalNotification *notificacion = [[UILocalNotification alloc] init];
    notificacion.fireDate = [pickerCaducidad date];
    notificacion.timeZone = [NSTimeZone defaultTimeZone];
    
    notificacion.alertBody = @"AppPartesAccidentAmistosos";
    notificacion.alertAction = @"Mostrar";
    notificacion.soundName = UILocalNotificationDefaultSoundName;
    notificacion.applicationIconBadgeNumber = 1;
    
    NSDictionary *userDict = [NSDictionary dictionaryWithObject:textoNotificacion.text forKey:kNotificationTextKey];
    notificacion.userInfo = userDict;
    
    [[UIApplication sharedApplication] scheduleLocalNotification:notificacion];
    [notificacion autoContentAccessingProxy];
}

- (void)prepararNotificacion
{
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    [self programarNotificacion];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc
{
    [pickerCaducidad autoContentAccessingProxy];
    [txtNotificacion autoContentAccessingProxy];
    [textoNotificacion autoContentAccessingProxy];
    [super autoContentAccessingProxy];
}


+ (AppDelegate *)sharedAppDelegate {
    
    return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    NSLog( @"Starting UbiquityStoreManager on device: %@\n\n", [UIDevice currentDevice].name );
    
    return YES;
    
    ubiquityStoreManager = [[UbiquityStoreManager alloc] initStoreNamed:nil withManagedObjectModel:nil localStoreURL:nil
                                                    containerIdentifier:nil storeConfiguration:nil storeOptions:nil delegate:self];
}

#pragma mark Push Notifications Methods
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    NSLog(@"Mi device token es %@", deviceToken);
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error{
    NSLog(@"Error al obtener el token. Error: %@", error);
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"Contenido del JSON: %@", userInfo);
}

- (void)application:(UIApplication *)applicationd idFailToRegisterForRemoteNotificationsWithError:

(NSError *)error{
    
    NSLog(@"Error al obtener el token. Error: %@", error);
    
}


-(void)loadDB
{
    BOOL exito;
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSError *error;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
    
    NSString *libraryDirectory = [paths objectAtIndex:1];
    
    NSString *writableDBPath = [libraryDirectory stringByAppendingPathComponent:@"iCloud.es.companynetwortinternetsecurityapp.AppPartesAccidentAmistosos"];
    
    exito = [fileManager fileExistsAtPath:writableDBPath];
    
    if (exito) return;
    
   writableDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"iCloud.es.companynetwortinternetsecurityapp.AppPartesAccidentAmistosos"];
    
    exito;
    
    if (!exito) {
        NSAssert1(1, @"Error al cargar la base de datos, error = '%@'.", [error localizedDescription]);
    }
    
}


- (void)applicationWillTerminate:(UIApplication *)application {
    
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    [managedObjectContext performBlockAndWait:^{
        NSError *error = nil;
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error])
            NSLog( @"Unresolved error: %@\n%@", error, [error userInfo] );
    }];
}


#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (alertView == cloudContentHealingAlert) {
        if (buttonIndex == [alertView firstOtherButtonIndex]) {
            
            self.ubiquityStoreManager.cloudEnabled = YES;
        }
    }
    
    if (alertView == cloudContentCorruptedAlert) {
        if (buttonIndex == [alertView firstOtherButtonIndex]) {
            
            self.ubiquityStoreManager.cloudEnabled = YES;
        }
        else if (buttonIndex == [alertView firstOtherButtonIndex] + 1) {
            
            handleCloudContentWarningAlert = [[UIAlertView alloc] initWithTitle:@"Fix iCloud Now" message:
                                              @"This problem can usually be auto‑corrected by opening the app on another device where you recently made changes.\n"
                                              @"If you wish to correct the problem from this device anyway, it is possible that recent changes on another device will be lost."
                                                                       delegate:self
                                                              cancelButtonTitle:@"Back"
                                                              otherButtonTitles:@"Fix Anyway", nil];
            [handleCloudContentWarningAlert show];
        }
    }
    
    if (alertView == handleCloudContentWarningAlert) {
        if (buttonIndex == alertView.cancelButtonIndex) {
            
            [cloudContentCorruptedAlert show];
        }
        else if (buttonIndex == alertView.firstOtherButtonIndex) {
            
            [self.ubiquityStoreManager rebuildCloudContentFromCloudStoreOrLocalStore:YES];
        }
    }
    
    if (alertView == handleLocalStoreAlert) {
        if (buttonIndex == [alertView firstOtherButtonIndex]) {
            
            [self.ubiquityStoreManager deleteLocalStore];
        }
    }
}


#pragma mark - UbiquityStoreManagerDelegate

- (NSManagedObjectContext *)ubiquityStoreManager:(UbiquityStoreManager *)manager
          managedObjectContextForUbiquityChanges:(NSNotification *)note {
    
    return self.managedObjectContext;
}

- (void)ubiquityStoreManager:(UbiquityStoreManager *)manager willLoadStoreIsCloud:(BOOL)isCloudStore {
    
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    [managedObjectContext performBlockAndWait:^{
        NSError *error = nil;
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error])
            NSLog( @"Unresolved error: %@\n%@", error, [error userInfo] );
        
        [managedObjectContext reset];
    }];
    
    _managedObjectContext = nil;
}

- (void)ubiquityStoreManager:(UbiquityStoreManager *)manager didLoadStoreForCoordinator:(NSPersistentStoreCoordinator *)coordinator
                     isCloud:(BOOL)isCloudStore {
    
    NSManagedObjectContext *moc = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    moc.persistentStoreCoordinator = coordinator;
    moc.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy;
    _managedObjectContext = moc;
    
    dispatch_async( dispatch_get_main_queue(), ^{
        [cloudContentCorruptedAlert dismissWithClickedButtonIndex:[cloudContentCorruptedAlert cancelButtonIndex] animated:YES];
        [handleCloudContentWarningAlert dismissWithClickedButtonIndex:[handleCloudContentWarningAlert cancelButtonIndex] animated:YES];
    } );
}

- (void)ubiquityStoreManager:(UbiquityStoreManager *)manager failedLoadingStoreWithCause:(UbiquityStoreErrorCause)cause context:(id)context
                    wasCloud:(BOOL)wasCloudStore {
    
    dispatch_async( dispatch_get_main_queue(), ^{
        [ViewController description];
        
        if (!wasCloudStore && ![handleLocalStoreAlert isVisible]) {
            handleLocalStoreAlert = [[UIAlertView alloc] initWithTitle:@"Local Store Problem"
                                                               message:@"Your datastore got corrupted and needs to be recreated."
                                                              delegate:self
                                                     cancelButtonTitle:nil otherButtonTitles:@"Recreate", nil];
            [handleLocalStoreAlert show];
        }
    } );
}

- (BOOL)ubiquityStoreManager:(UbiquityStoreManager *)manager handleCloudContentCorruptionWithHealthyStore:(BOOL)storeHealthy {
    
    if (storeHealthy) {
        dispatch_async( dispatch_get_main_queue(), ^{
            if ([cloudContentHealingAlert isVisible])
                return;
            
            cloudContentHealingAlert = [[UIAlertView alloc]
                                        initWithTitle:@"iCloud Store Corruption"
                                        message:@"\n\n\n\nRebuilding cloud store to resolve corruption."
                                        delegate:self cancelButtonTitle:nil otherButtonTitles:@"Disable iCloud", nil];
            
            UIActivityIndicatorView *activityIndicator = [[UIActivityIndicatorView alloc]
                                                          initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
            activityIndicator.center = CGPointMake( 142, 90 );
            [activityIndicator startAnimating];
            [cloudContentHealingAlert addSubview:activityIndicator];
            [cloudContentHealingAlert show];
        } );
        
        return YES;
    }
    else {
        dispatch_async( dispatch_get_main_queue(), ^{
            if ([cloudContentHealingAlert isVisible] || [handleCloudContentWarningAlert isVisible])
                return;
            
            cloudContentCorruptedAlert = [[UIAlertView alloc]
                                          initWithTitle:@"iCloud Store Corruption"
                                          message:@"\n\n\n\nWaiting for another device to auto-correct the problem..."
                                          delegate:self cancelButtonTitle:nil otherButtonTitles:@"Disable iCloud", @"Fix Now", nil];
            
            UIActivityIndicatorView *activityIndicator = [[UIActivityIndicatorView alloc]
                                                          initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
            activityIndicator.center = CGPointMake( 142, 90 );
            [activityIndicator startAnimating];
            [cloudContentCorruptedAlert addSubview:activityIndicator];
            [cloudContentCorruptedAlert show];
        } );
        
        return NO;
    }
}


- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    if (url){
        NSString *str = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
        
        NSLog(@"The file contained: %@",str);
    }
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(flushData) name:@"flushData" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(syncData) name:@"syncData" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCommentsForPostId:) name:@"getComments" object:nil];
    
    [self showPostsInView];
}


- (void)syncData {
    [self remoteControlReceivedWithEvent:ViewController];
    
    [self remoteControlReceivedWithEvent:ViewController2];
}



- (void)showPostsInView {
    NSLog(@"starting with showPostsInView");
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Post" inManagedObjectContext:[self managedObjectContext]];
    [fetchRequest setEntity:entity];
    NSError *error;
    NSArray *fetchedObjects = [[self managedObjectContext] executeFetchRequest:fetchRequest error:&error];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"showPosts" object:fetchedObjects];
}

- (void)flushData {
    NSArray *entities = self.managedObjectModel.entities;
    for (NSEntityDescription *entityDescription in entities) {
        [self deleteAllObjectsWithEntityName:entityDescription.name];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"showPosts" object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"showComments" object:nil];
}

- (void)deleteAllObjectsWithEntityName:(NSString*)entityName {
    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:entityName];
    fetchRequest.includesPropertyValues = NO;
    fetchRequest.includesSubentities = NO;
    NSError *error;
    NSArray *items = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    for (NSManagedObject *managedObject in items) {
        [self.managedObjectContext deleteObject:managedObject];
    }
}

- (BOOL)checkIfPostIdExists:(NSNumber*)postId {
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Post" inManagedObjectContext:[self managedObjectContext]];
    [fetchRequest setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"postId == %@", postId];
    [fetchRequest setPredicate:predicate];
    NSError *error;
    NSArray *items = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    return ([items count] > 0);
}

- (BOOL)checkIfCommentIdExists:(NSNumber*)commentId {
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"PostComment" inManagedObjectContext:[self managedObjectContext]];
    [fetchRequest setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"comId == %@", commentId];
    [fetchRequest setPredicate:predicate];
    NSError *error;
    NSArray *items = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    return ([items count] > 0);
}


@end
