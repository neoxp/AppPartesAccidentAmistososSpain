//
//  AppDelegate.h
//  AppPartesAccidentAmistosos
//
//  Created by Hackermaster on 20/04/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "TablaPartesTableViewController.h"
#import "WelcomeViewController.h"
#import "ShareViewController.h"
#import "ConflictViewController.h"
#import "DocumentViewController.h"
#import "ListViewController.h"
#import "ConductorACell.h"
#import "FotoYFirmaConductorACell.h"
#import "FotoYFirmaConductorBCell.h"
#import "ConductorBCell.h"
#import "ViewController.h"
#import "TablaPartesTableViewController.h"
#import "UbiquityStoreManager.h"


#import "ParteB.h"
#import "ParteB+CoreDataProperties.h"
#import "DatosID.h"
#import "DatosID.h"
#import "ParteB.h"
#import "ParteA.h"
#import "ParteA+CoreDataProperties.h"
#import "ParteA.h"
#import "DatosID.h"


@class ViewController,ViewController2;

@class User;

@interface AppDelegate : UIResponder<UIApplicationDelegate, UIAlertViewDelegate, UbiquityStoreManagerDelegate,iCloudDelegate,iCloudDocumentDelegate>{
    
    NSString *databaseName;
    NSString *databasePath;
    
    UIDatePicker *pickerCaducidad;
    UITextView *txtNotificacion;
    UITextField *textoNotificacion;
}

@property (nonatomic, retain) IBOutlet UIDatePicker *pickerCaducidad;
@property (nonatomic, retain) IBOutlet UITextView *txtNotificacion;
@property (nonatomic, retain) IBOutlet UITextField *textoNotificacion;

-(void)despliegaNotificacion:(NSString *)mensaje;
- (void)prepararNotificacion;
- (void)programarNotificacion;

// Variables de la base de datos
@property (nonatomic, retain) NSString *databaseName;
@property (nonatomic, retain) NSString *databasePath;

-(void)loadDB;


@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UIViewController *viewOrientations;
@property (strong, nonatomic) UIViewController *ViewController;
@property (strong, nonatomic) UIViewController *PrincipalViewController;
@property (strong, nonatomic) UITableViewController *ConfiguracioViewController;


@property (nonatomic, retain, readonly) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain, readonly) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, retain, readonly) NSPersistentStoreCoordinator*persistentStoreCoordinator;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;
extern NSString *kNotificationTextKey;


@property(strong, nonatomic) UINavigationController *navigationController;
@property(strong, nonatomic) UISplitViewController *splitViewController;
@property(strong, nonatomic) UbiquityStoreManager *ubiquityStoreManager;

+ (AppDelegate *)sharedAppDelegate;
- (User *)primaryUser;
@end
