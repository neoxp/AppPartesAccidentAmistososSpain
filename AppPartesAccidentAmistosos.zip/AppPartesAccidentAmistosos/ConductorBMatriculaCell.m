//
//  ConductorBMatriculaCell.m
//  AppPartesAccidentAmistosos
//
//  Created by HackerWebMaster on 4/8/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import "ConductorBMatriculaCell.h"

@interface ConductorBMatriculaCell ()
-(void) VerificarDatosFormulariPartesAccicentAmistosos;
- (void)changrGreeting;
@end

@implementation ConductorBMatriculaCell
@synthesize textFieldMatricula;



- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
- (void)viewDidUnload
{
    [self setTextFieldMatricula:nil];
    
}


- (void)viewDidLoad
{
    [self VerificarDatosFormulariPartesAccicentAmistosos];
    [self changrGreeting];
    [self enviarDatos];
    [textFieldMatricula becomeFirstResponder];
    
    
}



- (BOOL)textFieldShouldReturn:(UITextField *)campo {
    if (campo.tag==1) {
        [textFieldMatricula becomeFirstResponder];
        NSLog(StringMatricula ,@"Insertar datos companyia");
    }
    
    
    
    else {
        [textFieldMatricula resignFirstResponder];
        
    }
    return YES;
    
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self animateTextField:textFieldMatricula up:YES];
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    [self animateTextField:textFieldMatricula up:NO];
    
}

-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    int movementDistance = -100;
    float movementDuration = 0.3f;
    int movement = (up ? movementDistance : -movementDistance);
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    [UIView commitAnimations];
    
}

- (void)enviarDatos{
    [textFieldMatricula becomeFirstResponder];
    NSLog(textFieldMatricula.text);
    if ([textFieldMatricula.text isEqualToString:StringMatricula]) {
        NSLog(textFieldMatricula.text ,@"Datos Introducidos correctamente");
    }else{
        NSLog(textFieldMatricula.text,@"Datos no Introducidos correctamente");
    }
}




-(void)changrGreeting{
    
    self->StringMatricula = textFieldMatricula.text;
    
    NSString *nameStringMatricula = StringMatricula;
    
    
    
    if ([StringMatricula length] == 0)
        
    {
        
        nameStringMatricula =@"   ";
        
    }
    
    
}



-(void) VerificarDatosFormulariPartesAccicentAmistosos{
    
    self->StringMatricula = textFieldMatricula.text;
    
    NSString *nameStringMatricula = StringMatricula;
    
    
    
    NSString *queryURL = [NSString localizedStringWithFormat:textFieldMatricula.text];
    
    
    NSURL *url = [NSURL URLWithString:queryURL];
    
    NSString *jsonString = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
    
    NSLog(@"el id de l Object cargara los datos de la lista y los mostrara");
    
    id object = [ ArrayDatosLista initWithObjects:textFieldMatricula.text,nil];
    
    NSLog(@"el id de l Object cargara los datos de la lista y los mostrara");
    
    
    if ([object isKindOfClass:[NSDictionary class]]) {
        NSDictionary *objectAsDictionary = (NSDictionary *) object;
        id results = [objectAsDictionary valueForUndefinedKey:@"A"];
        if ([results isKindOfClass:[NSArray class]]) {
            
            
            
            NSArray *arr = [NSArray arrayWithObjects: @"textFieldMatricula", nil];
            [arr componentsJoinedByString: @","];
            
            
            NSError *error = nil;
            
            NSData *data = [NSJSONSerialization dataWithJSONObject:arr=ArrayDatosLista options:kNilOptions error:&error];
            
            NSString *str = [[NSString alloc] initWithData:data encoding:NSTextCheckingTypeTransitInformation];
            
            ArrayDatosLista = results;
            
            ArrayDatosLista = [ArrayDatosLista initWithObjects:textFieldMatricula.text,nil];
            
            for (object in arr=ArrayDatosLista=results)
                if ([textFieldMatricula.text isEqualToString:StringMatricula],INFINITY==true) {
                    
                    
                    
                    self->StringMatricula = textFieldMatricula.text;
                    
                    NSString *nameStringMatricula = StringMatricula;
                    
                    
                    
                    
                    NSLog(@"Sigue buscado los datos que esten todos comprobados y todos ya completos");
                    
                    NSLog(@"Si no estan completos seguira buscando en la lista los datos que hacen falta rellenar");
                    
                    
                    [textFieldMatricula becomeFirstResponder];
                    NSLog(textFieldMatricula.text,@"%@, ," ,@"Comprovando los datos", TIME_RELATIVE
                          
                          );
                    if ([textFieldMatricula.text isEqualToString:@"Companyia"]) {
                        NSLog(@"Datos Introducidos correctamente");
                        
                        ([textFieldMatricula.text isEqualToString:StringMatricula]);
                        
                    }else{
                        NSLog(textFieldMatricula.text ,@"Companyia");
                        
                    }
                    ArrayDatosLista = results;
                    NSLog(textFieldMatricula.text ,@"Mostrando Resultado de los datos",[textFieldMatricula.text isEqualToString:StringMatricula] );
                }
            
        }
    }
    if ([object isKindOfClass:[NSArray class]]) {
        ArrayDatosLista = object;
        
    }
    
    
}

-(void) touchesBegan :(NSSet *) touches withEvent:(UIEvent *)event

{
    
    [textFieldMatricula resignFirstResponder];
    
    
    [super touchesBegan:touches withEvent:event];
    
}


- (void)dealloc {
    
    [textFieldMatricula autoContentAccessingProxy];
    
    
    [StringMatricula autoContentAccessingProxy];
    [super autoContentAccessingProxy];
    
}

-(IBAction)EnviarFormulario:(id)sender {
    NSArray *toRecipents = [NSArray arrayWithObject:@"ejemplo@lacaixa.es"];
    
    MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
    mc.mailComposeDelegate = self;
    
    [mc setMessageBody:StringMatricula isHTML:NO];
    
    
    
    [mc setToRecipients:toRecipents];
    
    [textFieldMatricula becomeFirstResponder];
    
    NSLog(textFieldMatricula.text,@"%@, ,",@"Comprobando los datos"
          , TIME_RELATIVE
          );
    
    if  ([textFieldMatricula.text isEqualToString:StringMatricula]){
        NSLog(@"Datos Introducidos correctamente");
        ([textFieldMatricula.text isEqualToString:StringMatricula]);
        
    }else{
        NSLog(@"Datos no Introducidos correctamente");
        ([textFieldMatricula.text isEqualToString:StringMatricula]);
        
        NSLog(textFieldMatricula.text,@"Mostrando Resultado de los datos",
              [textFieldMatricula.text isEqualToString:StringMatricula]  );
        
        NSLog(textFieldMatricula.text, @"Mostrando Resultado de los datos",[textFieldMatricula.text isEqualToString:StringMatricula]);
        
    }
    
}


- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            cargado.text = @"Cancelado";
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            cargado.text = @"Guardado";
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            cargado.text = @"Enviado";
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    
}



@end
