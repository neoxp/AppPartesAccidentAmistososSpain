//
//  DatosID.m
//  AppPartesAccidentAmistosos
//
//  Created by HackerMaster   on 16/11/16.
//  Copyright © 2016 Emili Marqués Forés. All rights reserved.
//

#import "DatosID.h"
#import "ParteB.h"

@implementation DatosID

// Insert code here to add functionality to your managed object subclass

@end
