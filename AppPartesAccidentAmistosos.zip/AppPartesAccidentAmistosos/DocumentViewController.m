
#import "DocumentViewController.h"
#import "ListViewController.h"
#import "ConductorACell.h"
#import "FotoYFirmaConductorACell.h"
#import "FotoYFirmaConductorBCell.h"
#import "ConductorBCell.h"
#import "ViewController.h"
#import "TablaPartesTableViewController.h"

@interface DocumentViewController ()

@end

@implementation DocumentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    if (self.fileName == nil || [self.fileName isEqualToString:@""]) {
        NSString *newFileName = [self generateFileNameWithExtension:@"txt"];
        self.title = newFileName;
        self.fileName = newFileName;
        self.textFieldCompanyia.text = @"Document text";
        self.textFieldMatricula.text = @"Document text";
        self.StringNovaMatricula== @"Document text";
        self.textFieldDNI.text = @"Document text";
        self.textFieldNpoliza.text = @"Document text";
        self.textFieldConductor.text = @"Document text";
        self.textFieldDNIConductor.text = @"Document text";
        self.textFieldFirmaDigital.text = @"Document text";
        self.textFieldFirmaDigitalSegonaPersona.text = @"Document text";
    } else {
        self.title = self.fileName;
        self.textFieldCompanyia.text = self.fileText;
         self.textFieldMatricula.text = self.fileText;
         self.StringNovaMatricula = self.fileText;
         self.textFieldDNI.text = self.fileText;
         self.textFieldNpoliza.text = self.fileText;
         self.textFieldConductor.text = self.fileText;
         self.textFieldDNIConductor.text = self.fileText;
         self.textFieldFirmaDigital.text = self.fileText;
         self.textFieldFirmaDigitalSegonaPersona.text = self.fileText;
    }
}



- (void)viewWillDisappear:(BOOL)animated {
    if ([self.title isEqualToString:@"iCloud Document"] || self.fileName == nil || [self.fileName isEqualToString:@""]) {
        NSString *newFileName = [self generateFileNameWithExtension:@"txt"];
        NSData *fileData = [self.textFieldCompanyia.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldMatricula.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.StringNovaMatricula dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldDNI.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldNpoliza.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldConductor.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldDNIConductor.text dataUsingEncoding:NSUTF8StringEncoding];
        
         fileData = [self.textFieldFirmaDigital.text dataUsingEncoding:NSUTF8StringEncoding];
        
         fileData = [self.textFieldFirmaDigitalSegonaPersona.text dataUsingEncoding:NSUTF8StringEncoding];
        
        
        [[iCloud sharedCloud] saveAndCloseDocumentWithName:newFileName withContent:fileData completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
            if (!error) {
                NSLog(@"iCloud Document, %@, saved with text: %@", cloudDocument.fileURL.lastPathComponent, [[NSString alloc] initWithData:documentData encoding:NSUTF8StringEncoding]);
            } else {
                NSLog(@"iCloud Document save error: %@", error);
            }
            
            [super viewWillDisappear:YES];
        }];
    } else {
        NSData *fileData = [self.textFieldCompanyia.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldMatricula.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.StringNovaMatricula dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldDNI.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldNpoliza.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldConductor.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldDNIConductor.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldFirmaDigital.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldFirmaDigitalSegonaPersona.text dataUsingEncoding:NSUTF8StringEncoding];

        
        [[iCloud sharedCloud] saveAndCloseDocumentWithName:self.fileName withContent:fileData completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
            if (!error) {
                NSLog(@"iCloud Document, %@, saved with text: %@", cloudDocument.fileURL.lastPathComponent, [[NSString alloc] initWithData:documentData encoding:NSUTF8StringEncoding]);
            } else {
                NSLog(@"iCloud Document save error: %@", error);
            }
            
            [super viewWillDisappear:YES];
        }];
    }
}

- (NSString *)generateFileNameWithExtension:(NSString *)extensionString {
    NSDate *time = [NSDate date];
    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    [dateFormatter setDateFormat:@"dd-MM-yyyy-hh-mm-ss"];
    NSString *timeString = [dateFormatter stringFromDate:time];
    
    NSString *fileName = [NSString stringWithFormat:@"%@.%@", timeString, extensionString];
    
    return fileName;
}

- (IBAction)shareDocument:(id)sender {
    if ([self.title isEqualToString:@"iCloud Document"]
        || self.textFieldCompanyia == nil  ||
        self.textFieldMatricula == nil ||
         self.StringNovaMatricula == nil ||
        self.textFieldDNI == nil  ||
        self.textFieldNpoliza == nil ||
       self.textFieldConductor == nil  ||
        self.textFieldDNIConductor == nil ||
        self.textFieldFirmaDigital == nil
        ||   self.textFieldFirmaDigitalSegonaPersona == nil ||
        [self.fileName isEqualToString:@""] == YES)
    {
        NSString *newFileName = [self generateFileNameWithExtension:@"txt"];
        NSData *fileData = [self.textFieldCompanyia.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldMatricula.text dataUsingEncoding:NSUTF8StringEncoding];
        
         fileData = [self.StringNovaMatricula dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldDNI.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldNpoliza.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldConductor.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldDNIConductor.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldFirmaDigital.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldFirmaDigitalSegonaPersona.text dataUsingEncoding:NSUTF8StringEncoding];

        
        self.title = newFileName;
        self.fileName = newFileName;
        
        [[iCloud sharedCloud] saveAndCloseDocumentWithName:newFileName withContent:fileData completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
            if (!error) {
                NSLog(@"iCloud Document, %@, saved with text: %@", cloudDocument.fileURL.lastPathComponent, documentData);
                
                [[iCloud sharedCloud] shareDocumentWithName:newFileName completion:^(NSURL *sharedURL, NSDate *expirationDate, NSError *error) {
                    if (!error) {
                        NSLog(@"iCloud Document, %@, shared to public URL: %@ until expiration date: %@", cloudDocument.fileURL.lastPathComponent, sharedURL, expirationDate);
                        self.fileLink = [sharedURL absoluteString];
                        
                        NSString *formatString = [NSDateFormatter dateFormatFromTemplate:@"EdMMM" options:0 locale:[NSLocale currentLocale]];
                        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                        [dateFormatter setDateFormat:formatString];
                        NSString *dateString = [dateFormatter stringFromDate:expirationDate];
                        self.fileExpirationDate = dateString;
                        
                        [self performSegueWithIdentifier:@"share" sender:self];
                    } else {
                        NSLog(@"iCloud Document share error: %@", error);
                    }
                }];
            } else {
                NSLog(@"iCloud Document save error: %@", error);
            }
        }];
    } else {
        [[iCloud sharedCloud] shareDocumentWithName:self.fileName completion:^(NSURL *sharedURL, NSDate *expirationDate, NSError *error) {
            if (!error) {
                NSLog(@"iCloud Document, %@, shared to public URL: %@ until expiration date: %@", self.fileName, sharedURL, expirationDate);
                self.fileLink = [sharedURL absoluteString];
                
                NSString *formatString = [NSDateFormatter dateFormatFromTemplate:@"EdMMM" options:0 locale:[NSLocale currentLocale]];
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:formatString];
                NSString *dateString = [dateFormatter stringFromDate:expirationDate];
                self.fileExpirationDate = dateString;
                
                [self performSegueWithIdentifier:@"share" sender:self];
            } else {
                NSLog(@"iCloud Document share error: %@", error);
            }
        }];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView {
    if ([self.title isEqualToString:@"iCloud Document"] || self.fileName == nil || [self.fileName isEqualToString:@""]) {
        NSString *newFileName = [self generateFileNameWithExtension:@"txt"];
        NSData *fileData = [self.textFieldCompanyia.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldMatricula.text dataUsingEncoding:NSUTF8StringEncoding];
        
         fileData = [self.StringNovaMatricula dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldDNI.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldNpoliza.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldConductor.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldDNIConductor.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldFirmaDigital.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldFirmaDigitalSegonaPersona.text dataUsingEncoding:NSUTF8StringEncoding];

        [[iCloud sharedCloud] saveAndCloseDocumentWithName:newFileName withContent:fileData completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
            NSLog(@"Saved changes to %@: %@", [cloudDocument.fileURL lastPathComponent], documentData);
        }];
    } else {
        NSData *fileData = [self.textFieldCompanyia.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldMatricula.text dataUsingEncoding:NSUTF8StringEncoding];
        
         fileData = [self.StringNovaMatricula dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldDNI.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldNpoliza.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldConductor.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldDNIConductor.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldFirmaDigital.text dataUsingEncoding:NSUTF8StringEncoding];
        
        fileData = [self.textFieldFirmaDigitalSegonaPersona.text dataUsingEncoding:NSUTF8StringEncoding];

        [[iCloud sharedCloud] saveAndCloseDocumentWithName:self.fileName withContent:fileData completion:^(UIDocument *cloudDocument, NSData *documentData, NSError *error) {
            NSLog(@"Saved changes to %@: %@", [cloudDocument.fileURL lastPathComponent], documentData);
        }];
    }
}



@end
