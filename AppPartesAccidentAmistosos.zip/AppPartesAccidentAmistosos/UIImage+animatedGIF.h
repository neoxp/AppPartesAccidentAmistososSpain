//
//  ViewController.h
//  AppPartesAccidentAmistosos
//
//  Created by Hackermaster on 20/04/16.
//  Copyright (c) 2016 Emili Marqués Forés. All rights reserved.
//

#import <ImageIO/ImageIO.h>

#import <UIKit/UIKit.h>


@interface UIImage (animatedGIF)


@end
