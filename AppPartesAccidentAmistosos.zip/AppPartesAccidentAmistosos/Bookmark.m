//
//  Bookmark.m
//  bolduoptic
//
//  Created by HackerWebMaster on 2/8/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//


#import "Bookmark.h"
#import "MyTextDocument.h"
#import "ViewController.h"
#import "ViewController2.h"
#import <AudioToolbox/AudioServices.h>


#define kBookmarkName   @"Documents"
#define kBookmarkURL    @"iCloud.es.companynetwortinternetsecurityapp.AppPartesAccidentAmistosos"

@implementation Bookmark

@synthesize name = _name, url = _url;

#pragma mark -
#pragma mark Initialization
- (id)initWithName:(NSString *)name andURL:(NSString *)url {
    self = [super init];
    
    if (self) {
        self.name = name;
        self.url = url;
    }
    
    return self;
}

#pragma mark -
#pragma mark NSCoding Protocol
- (void)encodeWithCoder:(NSCoder *)coder {
    [coder encodeObject:self.name forKey:kBookmarkName];
    [coder encodeObject:self.url forKey:kBookmarkURL];
}

- (id)initWithCoder:(NSCoder *)coder  {
    self = [super init];
    
    if (self != nil) {
        self.name = [coder decodeObjectForKey:kBookmarkName];
        self.url = [coder decodeObjectForKey:kBookmarkURL];
    }
    
    return self;
}

@end